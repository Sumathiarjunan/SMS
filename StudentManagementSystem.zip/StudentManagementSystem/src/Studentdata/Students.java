package Studentdata;

import java.util.Scanner;

public class Students {

	    private String Name;
	    private int StudentId;
	    private String CourseName;
	    private String CourseDuration;
	    private double CourseFees;
	    private double balance;
		public String getName() {
			return Name;
		}
		public void setName(String name) {
			Name = name;
		}
		public int getStudentId() {
			return StudentId;
		}
		public void setStudentId(int studentId) {
			StudentId = studentId;
		}
		public String getCourseName() {
			return CourseName;
		}
		public void setCourseName(String courseName) {
			CourseName = courseName;
		}
		public String getCourseDuration() {
			return CourseDuration;
		}
		public void setCourseDuration(String courseDuration) {
			CourseDuration = courseDuration;
		}
		public double getCourseFees() {
			return CourseFees;
		}
		public void setCourseFees(double courseFees) {
			CourseFees = courseFees;
		}
		public double getBalance() {
			return balance;
		}
		public void setBalance(double balance) {
			this.balance = balance;
		}
		
	    
}


	
	