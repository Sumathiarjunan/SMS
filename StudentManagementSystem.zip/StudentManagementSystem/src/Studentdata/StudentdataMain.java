package Studentdata;

import java.util.Scanner;

public class StudentdataMain extends Students {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StudentdataMain student = new StudentdataMain();

        System.out.println("Enter your name:");
        student.setName(sc.nextLine());
        student.setStudentId(1000);

        System.out.println("Enroll Courses");
        System.out.println("-------");
        System.out.println("Course we have..");
        System.out.println("1. C#");
        System.out.println("2. WEB DEVELOPMENT");
        System.out.println("3. AI");
        System.out.println("4. SOFTWARE TESTING");
        System.out.println("Which course do you want to learn?");
        
        int choice = sc.nextInt();
        sc.nextLine();  // Consume the newline character left in the buffer
        
        switch (choice) {
            case 1:
                student.setCourseName("C#");
                student.setCourseDuration("5 months");
                student.setCourseFees(10000);
                break;
            case 2:
                student.setCourseName("WEB DEVELOPMENT");
                student.setCourseDuration("3 months");
                student.setCourseFees(15000);
                break;
            case 3:
                student.setCourseName("AI");
                student.setCourseDuration("12 months");
                student.setCourseFees(30000);
                break;
            case 4:
                student.setCourseName("SOFTWARE TESTING");
                student.setCourseDuration("6 months");
                student.setCourseFees(6000);
                break;
            default:
                System.out.println("this courses not available");
                return;
        }

        System.out.println("You have chosen " + student.getCourseName());
        System.out.println("Course duration: " + student.getCourseDuration());
        System.out.println("Course fees: " + student.getCourseFees());

        System.out.println("Enter the amount you want to pay:");
        double payment = sc.nextDouble();
        
        double balance = student.getCourseFees() - payment;
        student.setBalance(balance);

        System.out.println("Student name: " + student.getName());
        System.out.println("Student id: " + student.getStudentId());
        System.out.println("Paid fees: " + payment);
        System.out.println("Remaining balance: " + balance);

        if (balance == 0) {
            System.out.println("You have paid the full fees.");
        } else {
            System.out.println("You have not paid the full fees.");
        }
    }
}
